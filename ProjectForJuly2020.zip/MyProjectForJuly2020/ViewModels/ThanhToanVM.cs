﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyProjectForJuly2020.ViewModels
{
    public class ThanhToanVM
    {
        public bool CungThongTinNguoiMua { get; set; }
        public string NguoiNhan { get; set; }
        public string DiaChiGiao { get; set; }
    }
}
